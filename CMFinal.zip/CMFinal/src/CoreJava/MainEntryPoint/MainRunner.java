package CoreJava.MainEntryPoint;



import CoreJava.DAO.AttendingDAO;
import CoreJava.DAO.CourseDAO;
import CoreJava.DAO.StudentDAO;
import CoreJava.Models.Attending;
import CoreJava.Models.Course;
import CoreJava.Models.Student;


import java.util.*;

import static CoreJava.DAO.AttendingDAO.getStudentCourse;
import static CoreJava.DAO.CourseDAO.AddCourses;
import static CoreJava.DAO.StudentDAO.validateUser;


public class MainRunner {



    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";






    public static void main (String[]args) {

        List<Student> studentList = new ArrayList<>();
        List<Course> courseList = new ArrayList<>();
        List<Attending> attendingList = new ArrayList<>();

        // boolean isStudent= false;
        Scanner in = new Scanner(System.in);
        String email = " ";
        String pass = " ";

        StudentDAO.RegisterStudent(studentList);
        System.out.println("Welcome to PerScholars");

        System.out.println("Are a (Please select number): ");
        System.out.printf("1.  Student\n" + "2. Quit\n");
        int isStudent = in.nextInt();


        if (isStudent == 1) {

            // getStudents();
            System.out.println("Sign-In: ");
            System.out.println("Enter Student Email Address: ");
            email = in.next();
            System.out.println("Enter Password: ");
            pass = in.next();

            validateUser(studentList, email, pass);

            AddCourses(courseList);


            //AttendingDAO.getAttending();




            System.out.printf("1.  Register for a Course\n" + "2. Logout\n");
            int regCourse = in.nextInt();
            if (regCourse == 1) {
                System.out.println("MY Classes: ");

                getStudentCourse(attendingList,email);
                System.out.println("ALL Courses:  ");
                System.out.println(String.format("%1s%10s%15s%30s \r","#", "Course ID", "Course Name", "Course Instructor"));
                CourseDAO.getAllCourses();
                for (int a =0; a < courseList.size(); a++){
                    System.out.printf(String.format("%1s%8s%26s%11s \r\n", (a+1),courseList.get(a).getCourseID(),
                            courseList.get(a).getCourseName(), courseList.get(a).getInstructorsName()));
                }
                System.out.println("Which Course?");
                int chooseCourse = in.nextInt();

                if (chooseCourse == 1) {
                    String courseID = "CSI-101";
                    AttendingDAO.registerStudentToCourse(attendingList,email,courseID);

                }
                else if (chooseCourse == 2) {
                    String courseID = "ENL-101";
                    AttendingDAO.registerStudentToCourse(attendingList,email,courseID);
                }
                else if (chooseCourse == 3){
                    String courseID = "PSY-101";
                    AttendingDAO.registerStudentToCourse(attendingList,email,courseID);
                }
                else if (chooseCourse == 4){
                    String courseID = "PED-101";
                    AttendingDAO.registerStudentToCourse(attendingList,email,courseID);
                }
                else {
                    System.out.println("You entered an invalid selection");
                    System.exit(0);
                }
                System.out.println("MY UPDATED Courses");

                System.out.println(String.format("%5s%13s%30s \r", "Course ID", "Course Name", "Course Instructor"));
                String cID = "";
                String sEmail = "";
                for(Attending i: attendingList){
                    sEmail = i.getStudentEmail();
                    if(Objects.equals(sEmail,email)){
                        cID = i.getCourseID();
                        List<Course> clist = new ArrayList<>(CourseDAO.getAllCourses());
                        String cID2 = " ";
                        for (Course cs : clist){
                            cID2 = cs.getCourseID();
                            if(Objects.equals(cID2,cID)) {
                                System.out.println(String.format("%5s%24s%10s \r", cs.getCourseID(), cs.getCourseName(), cs.getInstructorsName()));
                                //     break;
                            }

                        }


                    }
                    continue;


                }



            }
            else if (regCourse == 2){
                System.out.println("You have successfully logout");
                System.exit(0);
            }
            else{
                System.out.println("Invalid entry");
                System.exit(0);
            }





        } else if (isStudent == 2) {
            System.out.println("You are not a student.");
            System.exit(0);
        }
        else {
            System.out.println("Invalid entry!");
        }

    }


}

