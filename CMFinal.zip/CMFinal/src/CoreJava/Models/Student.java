package CoreJava.Models;

public class Student {

    private String email = ""; //Student's current school email
    private String name = " "; // The full name of the student
    private String pass = " "; // Student's password in order to login

    public Student (String email, String name, String pass) {
        this.email = email;
        this.name = name;
        this.pass = pass;

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }




}
