package CoreJava.Models;

public class Attending {

    private String email;
    private String courseID;
    // private String studentEmail;


    public Attending (String courseID, String email) {
        this.courseID = courseID;
        this.email = email;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getStudentEmail() {
        return email;
    }

    public void setStudentEmail(String studentEmail) {
        this.email = email;
    }
}