package CoreJava.DAO;

import CoreJava.Models.Course;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class CourseDAO {
    // ====== CODE TO PARSE TO CSV FILE ====== *//
    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";

    //Course attributes index
    private static final int COURSE_ID_IDX = 0;
    private static final int COURSE_NAME_IDX = 1;
    private static final int COURSE_INSTRUCTOR_IDX = 2;
    // ===============REGISTER COURSES METHOD =====================
    //CSV file header
    private static final String FILE_HEADER = "CourseID,CourseName,InstructorName";

    public static void AddCourses(List<Course> courseList) {

        //List<Course> courseList = new ArrayList<>();

        Course course1 = new Course("CSI-101","Intro to Programming","Weller");
        Course course2 = new Course("ENL-101","Intro to English Lit","Blonger");
        Course course3 = new Course("PSY-101","Intro to Psychology ","Magnert");
        Course course4 = new Course("PED-101","Intro to Physical Ed","Longo");

        courseList.add(course1);
        courseList.add(course2);
        courseList.add(course3);
        courseList.add(course4);

        FileWriter fileWriter = null;


        try {
            String fileStorage = System.getProperty("user.home") + "/Courses.csv";
            //String fileName = System.getProperty("Courses.csv");
            fileWriter = new FileWriter(fileStorage);


            //Write the CSV file header
            fileWriter.append(FILE_HEADER.toString());

            //Add a new line separator after the header
            fileWriter.append(NEW_LINE_SEPARATOR);

            //Write a new course object list to the CSV file
            for (Course course : courseList) {
                fileWriter.append(course.getCourseID());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(course.getCourseName());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(course.getInstructorsName());
                fileWriter.append(NEW_LINE_SEPARATOR);
            }

            System.out.println("CSV file was created successfully !!!");


        } catch (Exception e) {
            System.out.println("Error in course Writer File !!!");
            e.printStackTrace();
        } finally {

            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }
        }
    }


    public static List getAllCourses() {

        List<Course> courseList = new ArrayList<>();

        BufferedReader fileReader = null;

        try {

            String line = "";
            String fileStorage = System.getProperty("user.home") + "/Courses.csv";

            //Create the file reader
            fileReader = new BufferedReader(new FileReader(fileStorage));

            //Read the CSV file header to skip it
            fileReader.readLine();

            //Read the file line by line starting from the second line
            while ((line = fileReader.readLine()) != null) {
                //Get all tokens available in line
                String[] tokens = line.split(COMMA_DELIMITER);
                if (tokens.length > 0) {
                    //Create a new course object and fill his  data
                    Course courses = new Course(tokens[COURSE_ID_IDX], tokens[COURSE_NAME_IDX], tokens[COURSE_INSTRUCTOR_IDX]);
                    courseList.add(courses);
                }
            }


            //System.out.println("Course ID \t"  + "Course ID \t" + "Course Instructor \t");




            //  for (Course a: courseList) {

            //}









            /*

            for (Course i : courseList) {
                System.out.println(i.getCourseID() + "\t" + i.getCourseName() + "\t" + i.getInstructorsName() );
            }
*/

        } catch (Exception e) {
            System.out.println("Error in CsvFileReader !!!");
            e.printStackTrace();
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {
                System.out.println("Error while closing fileReader !!!");
                e.printStackTrace();
            }
        }
        return courseList;

    }

}
