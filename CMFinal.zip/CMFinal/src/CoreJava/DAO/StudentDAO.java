/* **********************************************************
 * Final Project  -- Java Basics
 * Student DAO
 * @author Clifton Morris
 * @date May 25, 2018
 * @description     This class is going to be used to search
  *                 the csv files for student’s informa1on only.
 * ***************************************************************************************/


package CoreJava.DAO;


import CoreJava.Models.Student;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class StudentDAO {

    // ====== CODE TO PARSE TO CSV FILE ====== *//
    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";

    //Student attributes index
    private static final int STUDENT_EMAIL_IDX = 0;
    private static final int STUDENT_NAME_IDX = 1;
    private static final int STUDENT_PASS_IDX = 2;


    // ===============REGISTER STUDENTS METHOD =====================
    //CSV file header
    private static final String FILE_HEADER = "StudentEmail,StudentName,StudentPassword";


    public static void RegisterStudent(List<Student> studentList) {

        Student mike = new Student("mike@psc.org", "Mike Phils", "123");
        Student andrew = new Student("andy@psc.org", "Andrew LeBon", "456");
        Student jenny = new Student("jenny@psc.org", "Jenny Queen", "789");
        Student ruby = new Student("ruby@psc.org", "Ruby Emi", "1001");

        studentList.add(mike);
        studentList.add(andrew);
        studentList.add(jenny);
        studentList.add(ruby);

        FileWriter fileWriter = null;


        try {
            String fileName = System.getProperty("user.home") + "/Students.csv";
            //String fileName = System.getProperty("Students.csv");
            fileWriter = new FileWriter(fileName);


            //Write the CSV file header
            fileWriter.append(FILE_HEADER.toString());

            //Add a new line separator after the header
            fileWriter.append(NEW_LINE_SEPARATOR);

            //Write a new student object list to the CSV file
            for (Student student : studentList) {
                fileWriter.append(student.getEmail());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(student.getName());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(student.getPass());
                fileWriter.append(NEW_LINE_SEPARATOR);
            }

            System.out.println("CSV file was created successfully !!!");
            //getStudents(studentList);

        } catch (Exception e) {
            System.out.println("Error in Student Writer File !!!");
            e.printStackTrace();
        } finally {

            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }
        }
    }

    public static List getStudents() {

        List<Student> studentList = new ArrayList<>();


        BufferedReader fileReader = null;

        try {

            String line = "";
            String fileStorage = System.getProperty("user.home") + "/Students.csv";
            //String fileStorage = System.getProperty("Students.csv");
            //Create the file reader
            fileReader = new BufferedReader(new FileReader(fileStorage));

            //Read the CSV file header to skip it
            fileReader.readLine();

            //Read the file line by line starting from the second line
            while ((line = fileReader.readLine()) != null) {
                //Get all tokens available in line
                String[] tokens = line.split(COMMA_DELIMITER);
                if (tokens.length > 0) {
                    //Create a new student object and fill his  data
                    Student students = new Student(tokens[STUDENT_EMAIL_IDX], tokens[STUDENT_NAME_IDX], tokens[STUDENT_PASS_IDX]);
                    studentList.add(students);
                }
            }

            //studentList.toString();
            //Print the new student list
            for (Student i : studentList) {
                System.out.println("Student Email: " + i.getEmail() + "\nStudent Name: " +
                        i.getName() + "\nStudent Password: " + i.getPass());
            }


        } catch (Exception e) {
            System.out.println("Error in CsvFileReader !!!");
            e.printStackTrace();
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {
                System.out.println("Error while closing fileReader !!!");
                e.printStackTrace();
            }
        }
        return studentList;
    }
    // ===============GET STUDENTS BY EMAIL METHOD =====================

    public static List<Student> getStudentsByEmail(List<Student> studentList, String email) {

        for (Student i : studentList) {

            if (Objects.equals(i.getEmail(), email)) {
                String stuEmail = i.getEmail();
                String stuName = i.getName();
                String stuPass = i.getPass();
                //Student students = new Student(i.getEmail(), i.getName(), i.getPass());

                //return students;

            }
            // Student students = new Student(i.getEmail(), i.getName(), i.getPass());
            //studentList.add(students);
            System.out.println(i.getName());
        }
        return studentList;
    }

    // ===============GET VALIDATE USER METHOD =====================

    public static boolean validateUser(List<Student> studentList, String email, String pass) {


        boolean isValid= false;
        for (Student i : studentList) {

            //           System.out.println(i.getEmail());
            String stu = i.getEmail();
            String inEmail = email;
            isValid = (Objects.equals(stu,email) && (Objects.equals(i.getPass(),pass)));
            // i.getName() + "\nStudent Password: " + i.getPass());
            if (isValid) {

                return isValid;
            }



        }
        if(isValid){

            return isValid;

        }
        System.out.println("Wrong Credentials!");
        System.exit(0);
        return false;

    }



}
