package CoreJava.DAO;

import CoreJava.Models.Attending;
import CoreJava.Models.Course;
import CoreJava.Models.Student;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class AttendingDAO {

    // ====== CODE TO PARSE TO CSV FILE ====== *//
    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";

    //Student attributes index
    private static final int ATTENDING_COURSEID_IDX = 0;
    private static final int ATTENDING_EMAIL_IDX = 1;

    private static final String FILE_HEADER = "courseID,email";

    //Course attributes index
    private static final int COURSE_ID_IDX = 0;
    private static final int COURSE_NAME_IDX = 1;
    private static final int COURSE_INSTRUCTOR_IDX = 2;
    // ===============REGISTER COURSES METHOD =====================
    //CSV file header
    private static final String CFILE_HEADER = "CourseID,CourseName,InstructorName";

    public static List getAttending() {

        List<Attending> attendingList = new ArrayList<>();

        BufferedReader fileReader = null;

        try {

            String fileStorage = System.getProperty("user.home") + "/Attending.csv";

            String line = "";

            //Create the file reader
            fileReader = new BufferedReader(new FileReader(fileStorage));

            //Read the CSV file header to skip it
            fileReader.readLine();

            //Read the file line by line starting from the second line
            while ((line = fileReader.readLine()) != null) {
                //Get all tokens available in line
                String[] tokens = line.split(COMMA_DELIMITER);
                if (tokens.length > 0) {
                    //Create a new student object and fill his  data
                    Attending attends = new Attending(tokens[ATTENDING_COURSEID_IDX], tokens[ATTENDING_EMAIL_IDX]);
                    attendingList.add(attends);
                }
            }


            for (int a = 0; a < attendingList.size(); a++) {
                System.out.println("#" + "\t" + "Course ID " + "\t" + "Student Email");
                System.out.println((a + 1) + "\t" + attendingList.get(a).getCourseID() +
                        "     " + attendingList.get(a).getStudentEmail());
            }


        } catch (Exception e) {
            System.out.println("Error in CsvFileReader !!!");
            e.printStackTrace();
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {
                System.out.println("Error while closing fileReader !!!");
                e.printStackTrace();
            }
        }

        return attendingList;

    }


    public static void registerStudentToCourse(List<Attending> attendingList, String email, String courseID) {

        List<Student> studentList = new ArrayList<>();
        List<Course> courseList = new ArrayList<>();

        for (int at = 0; at < attendingList.size(); at++) {
            if ((Objects.equals(attendingList.get(at).getCourseID(), courseID)) && (Objects.equals(attendingList.get(at).getStudentEmail(), email))) {
                getStudentCourse(attendingList,email);
            }
            else
            // if ((Objects.equals(attendingList.get(at).getCourseID(), courseID)) && (Objects.equals(attendingList.get(at).getStudentEmail(), email)))
            {
                //   attendingList.get(at).getCourseID()+ attendingList.get(at).getStudentEmail();
                Attending attends = new Attending(courseID,email);
                attendingList.add(attends);


                saveAttending(attendingList);
                break;
            }
            //  System.out.println(String.format("%1s%10s%15s% \r", courseList.get(cs).getCourseID(), courseList.get(cs).getCourseName(),
            //        courseList.get(cs).getInstructorsName()));
            //   System.out.println(courseList.get(cs).getCourseID() +  courseList.get(cs).getCourseName()+
            //           courseList.get(cs).getInstructorsName());

            //courseList.add(cs);

        }
    }

    // =============================== GET COURSES STUDENT IS ATTENDING BY EMAIL ===================== */
    public static List getStudentCourse(List<Attending> attendingList, String email) {


        BufferedReader fileReader = null;

        try {

            String fileStorage = System.getProperty("user.home") + "/Attending.csv";

            String line = "";

            //Create the file reader
            fileReader = new BufferedReader(new FileReader(fileStorage));

            //Read the CSV file header to skip it
            fileReader.readLine();

            //Read the file line by line starting from the second line
            while ((line = fileReader.readLine()) != null) {
                //Get all tokens available in line
                String[] tokens = line.split(COMMA_DELIMITER);
                if (tokens.length > 0) {
                    //Create a new student object and fill his  data
                    Attending attends = new Attending(tokens[ATTENDING_COURSEID_IDX], tokens[ATTENDING_EMAIL_IDX]);
                    attendingList.add(attends);
                }
            }

            System.out.println(String.format("%5s%13s%30s \r", "Course ID", "Course Name", "Course Instructor"));
            String cID = "";
            String sEmail = "";
            for(Attending i: attendingList){
                sEmail = i.getStudentEmail();
                if(Objects.equals(sEmail,email)) {
                    cID = i.getCourseID();
                    List<Course> courseList = new ArrayList<>(CourseDAO.getAllCourses());
                    String cID2 = " ";

                    for (Course cs : courseList){
                        cID2 = cs.getCourseID();
                        if(Objects.equals(cID2,cID)) {
                            System.out.println(String.format("%5s%24s%10s \r", cs.getCourseID(), cs.getCourseName(), cs.getInstructorsName()));
                            //     break;
                        }
                        //     continue;
                    }


                }
                continue;


            }









        } catch (Exception e) {
            System.out.println("Error in CsvFileReader !!!");
            e.printStackTrace();
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {
                System.out.println("Error while closing fileReader !!!");
                e.printStackTrace();
            }
        }
        // ======================== end retrieve course list =======
        //  courseList.add(clist);







        return attendingList;
    }


    public static void saveAttending(List<Attending> attendingList) {


        FileWriter fileWriter = null;


        try {
            String fileName = System.getProperty("user.home") + "/Attending.csv";
            //String fileName = System.getProperty("Students.csv");
            fileWriter = new FileWriter(fileName);


            //Write the CSV file header
            fileWriter.append(FILE_HEADER.toString());

            //Add a new line separator after the header
            fileWriter.append(NEW_LINE_SEPARATOR);

            //Write a new student object list to the CSV file
            for (Attending attend : attendingList) {
                fileWriter.append(attend.getCourseID());
                fileWriter.append(COMMA_DELIMITER);
                fileWriter.append(attend.getStudentEmail());
                fileWriter.append(NEW_LINE_SEPARATOR);
            }

            System.out.println("CSV file was created successfully !!!");
            //getStudents(studentList);

        } catch (Exception e) {
            System.out.println("Error in Student Writer File !!!");
            e.printStackTrace();
        } finally {

            try {
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }
        }
    }



}